import React from 'react';
import { Feedback } from '../types';

interface FeedbackDisplayProps {
  feedback: Feedback;
  slots: number;
}

const FeedbackDisplay: React.FC<FeedbackDisplayProps> = ({ feedback, slots }) => {
  const dots = [];
  
  // Green Pegs: Correct Color & Position (Mapped from feedback.black)
  for (let i = 0; i < feedback.black; i++) {
    dots.push(
      <div 
        key={`g-${i}`} 
        className="w-3 h-3 rounded-full bg-green-500 border border-green-600 shadow-[0_0_8px_rgba(34,197,94,0.8)]" 
        title="Đúng màu, đúng vị trí (Correct)" 
      />
    );
  }
  
  // Red Pegs: Correct Color, Wrong Position (Mapped from feedback.white)
  for (let i = 0; i < feedback.white; i++) {
    dots.push(
      <div 
        key={`r-${i}`} 
        className="w-3 h-3 rounded-full bg-red-500 border border-red-600 shadow-[0_0_8px_rgba(239,68,68,0.8)]" 
        title="Đúng màu, sai vị trí (Partial)" 
      />
    );
  }
  
  // White Pegs: Wrong Color / Empty (Filling the rest)
  const remaining = slots - dots.length;
  for (let i = 0; i < remaining; i++) {
    dots.push(
      <div 
        key={`w-${i}`} 
        className="w-3 h-3 rounded-full bg-white border border-slate-300 shadow-sm opacity-90" 
        title="Không có màu này (Incorrect)" 
      />
    );
  }

  // Adjust grid layout based on slots
  const gridCols = slots > 4 ? 'grid-cols-3' : 'grid-cols-2';

  return (
    <div className={`grid ${gridCols} gap-1.5 p-2 bg-slate-900/50 rounded-lg border border-slate-800`}>
      {dots}
    </div>
  );
};

export default FeedbackDisplay;