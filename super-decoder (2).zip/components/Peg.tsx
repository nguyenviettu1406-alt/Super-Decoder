import React from 'react';
import { ColorId } from '../types';
import { COLORS } from '../constants';

interface PegProps {
  color?: ColorId | null;
  size?: 'sm' | 'md' | 'lg';
  onClick?: () => void;
  selected?: boolean;
}

const Peg: React.FC<PegProps> = ({ color, size = 'md', onClick, selected }) => {
  const sizeClasses = {
    sm: 'w-6 h-6',
    md: 'w-10 h-10',
    lg: 'w-12 h-12',
  };

  const baseClasses = "rounded-full transition-all duration-200 ease-in-out border-2 box-border flex-shrink-0";
  
  if (!color) {
    return (
      <div 
        onClick={onClick}
        className={`${baseClasses} ${sizeClasses[size]} border-slate-700 bg-slate-800/50 ${selected ? 'border-slate-400 ring-2 ring-slate-500/50' : ''} ${onClick ? 'cursor-pointer hover:border-slate-600' : ''}`}
      />
    );
  }

  const colorConfig = COLORS[color];
  const activeClasses = `${colorConfig.bg} ${colorConfig.border} shadow-lg ${colorConfig.glow}`;

  return (
    <div
      onClick={onClick}
      className={`${baseClasses} ${sizeClasses[size]} ${activeClasses} ${onClick ? 'cursor-pointer hover:scale-110' : ''}`}
    />
  );
};

export default Peg;